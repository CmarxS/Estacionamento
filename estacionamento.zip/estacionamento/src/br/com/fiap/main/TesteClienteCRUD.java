package br.com.fiap.main;

import br.com.fiap.dao.ConnectionFactory;
import br.com.fiap.dao.clienteDAO;
import br.com.fiap.dto.Cliente;

import javax.swing.*;
import java.sql.Connection;
import java.util.ArrayList;

public class TesteClienteCRUD {
    public static void main(String[] args) {
        Connection con = ConnectionFactory.abrirConexao();
        int opcao, id;
        String aux, placa ,nome;
        Cliente cliente = new Cliente();
        clienteDAO dao = new clienteDAO(con);
        aux = JOptionPane.showInputDialog("Digite o que deseja fazer \n1- Add cliente \n2- Alterar cliente \n3- Deletar cliente \n4- Listar clientes");
        opcao = Integer.parseInt(aux);
        switch (opcao){
            case 1:
                aux = JOptionPane.showInputDialog("Insira o id");
                id = Integer.parseInt(aux);
                cliente.setIdCliente(id);
                nome = JOptionPane.showInputDialog("Insira o nome");
                cliente.setNomeCliente(nome);
                placa = JOptionPane.showInputDialog("Insira a placa");
                cliente.setPlaca(placa);
                dao.inserir(cliente);
                System.out.println(dao.inserir(cliente));
                break;
            case 2:
                aux = JOptionPane.showInputDialog("Insira o id do cliente que quer alterar");
                id = Integer.parseInt(aux);
                cliente.setIdCliente(id);
                nome = JOptionPane.showInputDialog("Insira o novo nome");
                cliente.setNomeCliente(nome);
                placa = JOptionPane.showInputDialog("Insira a nova placa");
                cliente.setPlaca(placa);

                JOptionPane.showMessageDialog(null, dao.alterar(cliente));
                break;
            case 3:
                aux = JOptionPane.showInputDialog("Insira o id");
                id = Integer.parseInt(aux);
                cliente.setIdCliente(id);
                JOptionPane.showMessageDialog(null, dao.excluir(cliente));
                break;
            case 4:
                ArrayList<Cliente> resultado = dao.listarTodos();
                if (resultado != null) {
                    for (Cliente clientes : resultado ){
                        String str = "ID's: "+ cliente.getIdCliente() + "Nomes: "+cliente.getNomeCliente() + "Placas: "+ cliente.getPlaca();
                    }

                }else {
                    JOptionPane.showMessageDialog(null,"ERRO!");
                }
                break;
        }


        ConnectionFactory.fecharConexao(con);
    }
}
